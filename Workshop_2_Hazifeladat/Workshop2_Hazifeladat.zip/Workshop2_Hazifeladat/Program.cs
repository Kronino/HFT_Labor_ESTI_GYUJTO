﻿using System.Xml;
using System.Xml.Serialization;

namespace Workshop2_Hazifeladat
{
    internal class Program
    {
        static void Main(string[] args)
        {

            #region Database init

            string xmlUrl = "https://raw.githubusercontent.com/Kronino/HFT_Labor_ESTI_GYUJTO/main/Workshop_2_Hazifeladat/pizza-database.xml";

            XmlSerializer serializer = new XmlSerializer(typeof(PizzaDatabase));
            PizzaDatabase pizzaDatabase;

            using (XmlReader reader = XmlReader.Create(xmlUrl))
            {
                pizzaDatabase = (PizzaDatabase)serializer.Deserialize(reader);
            }

            #endregion

            #region Feladat leírás

            // A következő feladatokat kell megoldani, a megoldásokat, elég csak egy változóba lekérdezni, nem kell őket kiiratni sehova, egyesével meg fogom őket nézni debugban. LinQ method/query syntax a használandó ízlés szerint.

            // Minden komment alatt legyen a saját megoldása. Fel lehet osztani a lekérdezéseket, több darab lekérdezésre, vagy egyben az egészet., lényeg hogy legyen meg az eredmény egy változóban.

            // Minden lekérdezést a következő objektumon/ adatbázison kell futtatni :      [pizzaDatabase.Pizzas]

            //például :   var 6_1 = Database.Pizzas.Select(..)..

            #endregion

            #region Feladatok

            // 6.1. Lekérdezi azokat a pizzákat, amelyek fantázianevében nem szerepel a "pizza" szó

            // 6.2. Lekérdezi az egyes méretek darabszámát, darabszám szerint csökkenő sorrendbe rendezve

            // 6.3.1. Lekérdezi azoknak a pizzáknak a nevét és típusát, amelyek legalább 4 feltéttel rendelkeznek

            // 6.3.2. Meghatározza a legalább 4 feltéttel rendelkező pizzák átlagos árát típusonként csoportosítva

            // 6.4. Lekérdezi az egyes méretek átlagos árát

            // 6.5. Meghatározza a legjobb értékű pizzát (ár & feltétek & méret)


            // 6.6. Lekérdezi a paradicsomos alapú pizzák számát, amelyek kevesebb feltéttel rendelkeznek, mint a második legtöbb feltéttel rendelkező pizza, és az áruk a középső ársávban található


            // 6.8. Meghatározza az egyes méretek darabszámát típusonként

            // 6.9. Lekérdezi azokat a pizzákat, amelyek neve rövidebb, mint a tészta vastagság és a feltétek számának kétszerese

            // 6.10. Meghatározza, mely pizzákból lehet kettőt vagy többet vásárolni, úgy, hogy még mindig kevesebb összegbe kerül, mint a legdrágább pizza

            // 6.11. Meghatározza, hogy a VIP pizzák vagy a normál pizzák átlagára alacsonyabb-e

            // 6.12. Meghatározza, hogy a VIP vagy a normál pizzák között fordul-e elő többször a 30-as méret

            // 6.13. Meghatározza, hogy a VIP vagy a normál pizzák között fordul-e elő átlagosan hosszabb elnevezés

            #endregion
        }
    }
}
