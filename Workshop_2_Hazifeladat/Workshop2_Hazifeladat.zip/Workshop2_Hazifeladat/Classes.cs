﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

[XmlRoot("PizzaDatabase")]
public class PizzaDatabase
{
    [XmlElement("Pizza")]
    public List<Pizza> Pizzas { get; set; }
}

public class Pizza
{
    [XmlElement("Type")]
    public PizzaType pizzaType { get; set; }

    [XmlElement("Size")]
    public PizzaSize pizzaSize { get; set; }

    [XmlElement("PastaThickness")]
    public int PastaThickness { get; set; }

    [XmlElement("NumberOfToppings")]
    public int NumberOfToppings { get; set; }

    [XmlElement("Price")]
    public int Price { get; set; }

    [XmlElement("FantasyName")]
    public string FantasyName { get; set; }

    [XmlAttribute("status")]
    public string Status { get; set; }
}

public class PizzaType
{
    [XmlAttribute("base")]
    public string Base { get; set; }

    [XmlText]
    public string TypeValue { get; set; }
}

public class PizzaSize
{
    [XmlAttribute("unit")]
    public string Unit { get; set; }

    [XmlText]
    public int SizeValue { get; set; }
}